package com.example.hwoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.io.File

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayText: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private var lastTotal = 0L
    private var lastIdle = 0L

    private val updater = object : Runnable {
        override fun run() {
            overlayText?.text = buildReport()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(170, 0, 0, 0))
            textSize = 12f
            setPadding(16, 10, 16, 10)
            text = "Loading..."
        }
        overlayText = tv

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16
            y = 120
        }

        try {
            windowManager.addView(tv, params)
        } catch (e: Exception) {
            stopSelf()
            return
        }
        handler.post(updater)
    }

    override fun onDestroy() {
        handler.removeCallbacks(updater)
        overlayText?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlayText = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val channelId = "hw_overlay"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "HW Overlay", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("HW Overlay is running")
            .setContentText("Open the app to stop it")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1, notification)
    }

    // ---------- Readings ----------

    private fun buildReport(): String {
        val lines = ArrayList<String>()
        lines.add("CPU use: " + cpuUsage())
        lines.add("CPU speed: " + cpuSpeed())
        lines.add("CPU temp: " + zoneTemp(listOf("cpu", "soc", "tsens", "mtktscpu", "big", "little")))
        lines.add("GPU temp: " + gpuTemp())
        lines.add("Battery: " + batteryTemp())
        lines.add("Thermal: " + thermalStatus())
        return lines.joinToString("\n")
    }

    // System-wide CPU usage. Android 8+ usually blocks this file, so N/A is normal.
    private fun cpuUsage(): String {
        return try {
            val line = File("/proc/stat").bufferedReader().use { it.readLine() }
                ?: return "N/A (blocked)"
            val p = line.trim().split(Regex("\\s+"))
            if (p.size < 8) return "N/A (blocked)"
            val nums = p.subList(1, 9.coerceAtMost(p.size)).map { it.toLong() }
            val total = nums.sum()
            val idle = nums[3] + nums.getOrElse(4) { 0L }
            val dTotal = total - lastTotal
            val dIdle = idle - lastIdle
            lastTotal = total
            lastIdle = idle
            if (dTotal <= 0L) "..." else "${((dTotal - dIdle) * 100 / dTotal)}%"
        } catch (e: Exception) {
            "N/A (blocked)"
        }
    }

    // Average CPU clock as a percent of max clock. A rough "how busy" hint.
    private fun cpuSpeed(): String {
        return try {
            val cpus = File("/sys/devices/system/cpu").listFiles { f ->
                f.name.matches(Regex("cpu[0-9]+"))
            } ?: return "N/A"
            var curSum = 0.0
            var maxSum = 0.0
            var count = 0
            for (c in cpus) {
                val cur = File(c, "cpufreq/scaling_cur_freq").readTextOrNull()?.trim()?.toDoubleOrNull()
                val max = File(c, "cpufreq/cpuinfo_max_freq").readTextOrNull()?.trim()?.toDoubleOrNull()
                if (cur != null && max != null && max > 0) {
                    curSum += cur
                    maxSum += max
                    count++
                }
            }
            if (count == 0) "N/A"
            else "${(curSum * 100 / maxSum).toInt()}% of max (${(curSum / count / 1000).toInt()} MHz avg)"
        } catch (e: Exception) {
            "N/A"
        }
    }

    private fun gpuTemp(): String {
        // Qualcomm (Snapdragon) paths
        val direct = listOf(
            "/sys/class/kgsl/kgsl-3d0/temp",
            "/sys/class/kgsl/kgsl-3d0/gpu_temp",
            "/sys/devices/virtual/kgsl/kgsl-3d0/temp"
        )
        for (path in direct) {
            val v = File(path).readTextOrNull()?.trim()?.toDoubleOrNull()
            if (v != null) return fmtTemp(v)
        }
        // Generic thermal zones (works on Snapdragon and MediaTek when readable)
        return zoneTemp(listOf("gpu", "mali", "adreno", "mtktsgpu"))
    }

    private fun zoneTemp(keywords: List<String>): String {
        return try {
            val zones = File("/sys/class/thermal").listFiles { f ->
                f.name.startsWith("thermal_zone")
            } ?: return "N/A"
            for (z in zones) {
                val type = File(z, "type").readTextOrNull()?.trim()?.lowercase() ?: continue
                if (keywords.any { type.contains(it) }) {
                    val v = File(z, "temp").readTextOrNull()?.trim()?.toDoubleOrNull()
                    if (v != null) return fmtTemp(v)
                }
            }
            "N/A"
        } catch (e: Exception) {
            "N/A"
        }
    }

    private fun fmtTemp(raw: Double): String {
        val c = when {
            raw > 1000 -> raw / 1000.0
            raw > 200 -> raw / 10.0
            else -> raw
        }
        return String.format("%.1f°C", c)
    }

    private fun batteryTemp(): String {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        return if (t == Int.MIN_VALUE) "N/A" else String.format("%.1f°C", t / 10.0)
    }

    private fun thermalStatus(): String {
        if (Build.VERSION.SDK_INT < 29) return "N/A"
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "OK"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
            else -> "N/A"
        }
    }

    private fun File.readTextOrNull(): String? {
        return try {
            if (exists() && canRead()) readText() else null
        } catch (e: Exception) {
            null
        }
    }
}
