package com.example.hwoverlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
        }

        val info = TextView(this).apply {
            text = "HW Overlay\n\n" +
                "Shows temperatures and CPU info on top of other apps.\n\n" +
                "Step 1: allow \"Display over other apps\".\n" +
                "Step 2: tap Start overlay.\n\n" +
                "Anything your phone does not let apps read will show N/A."
            textSize = 16f
        }

        val permButton = Button(this).apply {
            text = "1. Allow display over other apps"
            setOnClickListener {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }

        val startButton = Button(this).apply {
            text = "2. Start overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(
                        this@MainActivity,
                        "Do step 1 first",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    val svc = Intent(this@MainActivity, OverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
                    Toast.makeText(this@MainActivity, "Overlay started", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val stopButton = Button(this).apply {
            text = "Stop overlay"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }

        layout.addView(info)
        layout.addView(permButton)
        layout.addView(startButton)
        layout.addView(stopButton)
        setContentView(layout)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }
}
